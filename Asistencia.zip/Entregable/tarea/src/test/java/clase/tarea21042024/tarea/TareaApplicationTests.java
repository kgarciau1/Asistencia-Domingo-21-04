package clase.tarea21042024.tarea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TareaApplicationTests {

	@Test
	void contextLoads() {
	}

}
