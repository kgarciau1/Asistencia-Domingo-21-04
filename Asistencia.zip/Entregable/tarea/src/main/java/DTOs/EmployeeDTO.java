package DTOs;

public class EmployeeDTO {

}
