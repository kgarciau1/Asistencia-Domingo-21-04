package DTOs;

public class DepartmentDTO {

}
