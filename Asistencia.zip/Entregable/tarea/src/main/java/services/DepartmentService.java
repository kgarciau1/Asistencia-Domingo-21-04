package services;

import java.util.Optional;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import entities.department;
import repositories.DepartmentRepository;

@Service
public class DepartmentService {
    @Autowired
    private final DepartmentRepository departmentRepository;

    public DepartmentService(DepartmentRepository departmentRepository){
        this.departmentRepository = departmentRepository;
    }

    public List<Department> getList(){
        return departmentRepository.findAll();
    }

    public Optional<Department> getById(Long id){
        return departmentRepository.findById(id);
    }

    public Department create(Department department){
        return departmentRepository.save(department);
    }

    public List<Department> getListByActive(Boolean active){
        return departmentRepository.findByActive(active);
    }

}
