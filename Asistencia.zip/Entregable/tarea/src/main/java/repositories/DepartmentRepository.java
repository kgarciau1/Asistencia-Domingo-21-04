package repositories;

public interface DepartmentRepository {

}
