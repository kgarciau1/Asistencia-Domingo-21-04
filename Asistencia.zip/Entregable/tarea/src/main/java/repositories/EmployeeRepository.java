package repositories;

public interface EmployeeRepository {

}
