package controllers;

public class DepartmentController {

}
